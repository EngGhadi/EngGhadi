package com.example.project;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


import com.github.mfathi91.Number2Word;

public class MainActivity3 extends AppCompatActivity {
    TextView trans;
    Button bck;
    Button fin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        trans = findViewById(R.id.eng);
        String arabicNumber = getIntent().getStringExtra("ARABIC_NUMBER");
        translateAndDisplay(trans, arabicNumber);

        bck = findViewById(R.id.und);
        fin = findViewById(R.id.done);

    }

    public static void translateAndDisplay(TextView textView, String arabicNumber) {
        try {
            int number = Integer.parseInt(arabicNumber);
            String englishTranslation = Number2Word.getInstance().convert(number);
            textView.setText(englishTranslation);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            textView.setText("Invalid input");
        }
    }
}
